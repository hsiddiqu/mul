package mul;

public class Dist {
	public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
		return Math.sqrt((x2-x1) * (x2-x1) + (y2-y1) *(y2-y1) + (z2-z1) * (z2-z1));
		
	}

	public static void main(String[] args) {
		double [][] arr = {{-1,0,3}, {-1,-1,-1}, {4,1,1}, {2,0.5,9}, {3.5,2,-1}, {3,1.5,3}, {-1.5,4,2}, {5.5,4,-0.5}};
		int s1=0, s2 = 1;
		double dist = 0;
		  double nearDist=distance(arr[s1][0], arr[s1][1], arr[s1][2], arr[s2][0], arr[s2][1], arr[s2][2]);
        for(int i =0; i < arr.length;i++) {
        	for(int j = i + 1; j < arr.length; j++) {
        		
        	nearDist = distance(arr[i][0], arr[i][1], arr[i][2], arr[j][0], arr[j][1], arr[j][2]);
        	if(nearDist < dist) {
        		s1 =i;
        		s2 =j;
        		nearDist = dist;
        	}
        	}
        }
        System.out.println("Two closest two points are("+arr[s1][0]+", "+arr[s1][1] +", "+arr[s1][2]+")("+arr[s2][0]+","+arr[s2][1]+","+arr[s2][2]+")");
	}

	
	}

	

package mul;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;


public class testing {

	
	@Test
	public void testAddOnetoArray() {
		Dist dist = new Dist();
		int expected [] = new int[] {};
		
		assertArrayEquals (expected, dist.addOneToArray(new int[] {(int) -1.0, (int) 0.0, (int) 3.0}));

	}

	private void assertArrayEquals(int[] expected, int i) {
		// TODO Auto-generated method stub
		
		
	}

}
